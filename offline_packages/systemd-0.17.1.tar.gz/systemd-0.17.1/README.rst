SystemD for Python
==================

It's a proxy package for cysystemd package. It's has been renamed to avoid
of confusions. Please use the `cysystemd` instead of this package.

This package exists only for support users what do not upgrade to
the new package.
